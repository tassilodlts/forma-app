# Seitenleiste „Amphion“ (N-Panel im 3D-Fenster) und Einstellungen des Add-ons. Reihenfolge wie die Arbeit eines Architekten:
# 1 Modell importieren, 2 Szene, 3 Rendern, 4 KI-Rendering, 5 3D-Druck, Konto.
import bpy
from bpy.props import StringProperty
from . import cloud, rendern
from .kern import PAKET, modell_objekte


class AmphionEinstellungen(bpy.types.AddonPreferences):
    bl_idname = PAKET

    geraet: StringProperty(name='Device ID', default='', description='Random ID of this computer for free renders and the subscription')
    token: StringProperty(name='Credit key', default='', subtype='PASSWORD', description='at_… key from amphion3d.com/tools (shared with Rhino and the web tools)')
    lizenz: StringProperty(name='Amphion licence', default='', subtype='PASSWORD', description='An Amphion licence unlocks everything')
    cloud: StringProperty(name='Cloud URL', default='https://cloud.amphion3d.com')

    def draw(self, context):
        lay = self.layout
        lay.prop(self, 'token')
        lay.prop(self, 'lizenz')
        sp = lay.split(factor=0.75)
        sp.prop(self, 'geraet')
        sp.operator('amphion.refresh_account', icon='FILE_REFRESH')
        lay.prop(self, 'cloud')
        lay.label(text='Renders are saved in Pictures/Amphion. Help: amphion3d.com/blender', icon='INFO')


class _Basis:
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Amphion'


class AMPHION_PT_main(_Basis, bpy.types.Panel):
    bl_label = 'Amphion'
    bl_idname = 'AMPHION_PT_main'

    def draw_header(self, context):
        self.layout.label(icon='HOME')

    def draw(self, context):
        lay = self.layout
        col = lay.column(align=True)
        col.scale_y = 1.4
        col.operator('amphion.import_model', icon='IMPORT')
        hat = bool(modell_objekte(context.scene))
        r = col.row(align=True)
        r.enabled = hat
        r.operator('amphion.one_click_scene', icon='WORLD')
        r = col.row(align=True)
        r.enabled = hat
        r.operator('amphion.render_save', icon='RENDER_STILL')
        if cloud.stand.get('meldung'):
            lay.label(text=cloud.stand['meldung'], icon='TIME')


class AMPHION_PT_scene(_Basis, bpy.types.Panel):
    bl_label = 'Light & camera'
    bl_parent_id = 'AMPHION_PT_main'

    def draw(self, context):
        st = context.scene.amphion
        lay = self.layout
        lay.use_property_split = True
        lay.use_property_decorate = False
        lay.row().prop(st, 'licht_art', expand=True)
        if st.licht_art == 'SUN':
            lay.prop(st, 'ort')
            if st.ort == 'CUSTOM':
                lay.prop(st, 'breite')
                lay.prop(st, 'laenge')
                lay.prop(st, 'utc')
            r = lay.row(align=True)
            r.prop(st, 'tag')
            r.prop(st, 'monat')
            lay.prop(st, 'stunde', slider=True)
            lay.prop(st, 'nord')
            if 'sonne_hoehe' in st:
                lay.label(text='Sun: %d° high, from %d°' % (round(st['sonne_hoehe']), round(st['sonne_az']) % 360), icon='LIGHT_SUN')
        lay.prop(st, 'boden')
        if st.boden:
            lay.prop(st, 'schattenfaenger', text='Shadow catcher')
        lay.separator()
        lay.prop(st, 'kamera')
        lay.prop(st, 'seite')
        lay.operator('amphion.camera', text='Place camera', icon='CAMERA_DATA').art = st.kamera


class AMPHION_PT_render(_Basis, bpy.types.Panel):
    bl_label = 'Render'
    bl_parent_id = 'AMPHION_PT_main'

    def draw(self, context):
        sz = context.scene
        st = sz.amphion
        lay = self.layout
        aktiv = st.get('vorgabe', '')
        g = lay.grid_flow(row_major=True, columns=2, even_columns=True, align=True)
        for k, name, _ in rendern.VORGABEN:
            g.operator('amphion.render_preset', text=name, depress=(k == aktiv),
                       icon={'PREVIEW': 'SHADING_RENDERED', 'FINAL': 'RENDER_STILL', 'CLAY': 'SHADING_SOLID', 'NIGHT': 'LIGHT_SUN'}[k]).art = k
        lay.label(text='Image size: %d × %d' % (sz.render.resolution_x * sz.render.resolution_percentage // 100,
                                                 sz.render.resolution_y * sz.render.resolution_percentage // 100))
        g = lay.grid_flow(row_major=True, columns=3, even_columns=True, align=True)
        for k, name, *_ in rendern.FORMATE:
            g.operator('amphion.resolution', text=name.split(' ')[0] if k != 'A3_150' else 'A3 150', depress=(sz.amphion.get('format') == k)).art = k
        lay.prop(st, 'auto_belichtung')
        if not st.auto_belichtung:
            lay.prop(sz.view_settings, 'exposure')
        col = lay.column()
        col.scale_y = 1.3
        col.operator('amphion.render_save', icon='RENDER_STILL')
        lay.operator('amphion.open_folder', icon='FILE_FOLDER')


class AMPHION_PT_ai(_Basis, bpy.types.Panel):
    bl_label = 'AI render'
    bl_parent_id = 'AMPHION_PT_main'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        st = context.scene.amphion
        lay = self.layout
        lay.label(text='Photoreal image from your render, same geometry.')
        try:
            lay.prop(st, 'ki_text', text='', placeholder='Wishes: oak cladding, autumn, people…')
        except TypeError:   # Platzhaltertext erst ab 4.1
            lay.prop(st, 'ki_text', text='Wishes')
        lay.row().prop(st, 'ki_qualitaet', expand=True)
        col = lay.column()
        col.scale_y = 1.3
        col.operator('amphion.ai_render', icon='SHADERFX')
        s = cloud.stand
        if s.get('saldo') is not None:
            lay.label(text='Credit: %.2f €' % (s['saldo'] / 100), icon='FUND')
        elif s.get('ki_gratis') is not None:
            lay.label(text='%d free AI images left' % s['ki_gratis'], icon='FUND')
        lay.operator('amphion.buy_credit', icon='FUND')


class AMPHION_PT_print(_Basis, bpy.types.Panel):
    bl_label = '3D print'
    bl_parent_id = 'AMPHION_PT_main'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        lay = self.layout
        lay.label(text='Scale model as STL, 3MF or OBJ, checked.')
        lay.operator('amphion.export_print', icon='EXPORT')


class AMPHION_PT_account(_Basis, bpy.types.Panel):
    bl_label = 'Account'
    bl_parent_id = 'AMPHION_PT_main'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        lay = self.layout
        s = cloud.stand
        if s.get('abo'):
            lay.label(text='Subscription active · unlimited', icon='CHECKMARK')
            lay.operator('amphion.account', icon='PREFERENCES')
        else:
            if s.get('gratis') is not None:
                lay.label(text='%d of 10 free renders/exports left' % s['gratis'], icon='INFO')
            else:
                lay.label(text='10 free renders/exports, then 4 €/month', icon='INFO')
            lay.operator('amphion.subscribe_dialog', text='Subscribe · 4 €/month', icon='CHECKMARK')
        lay.operator('amphion.refresh_account', icon='FILE_REFRESH')
