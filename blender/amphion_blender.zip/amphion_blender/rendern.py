# Render-Vorgaben (Preview EEVEE, Final Cycles, White model, Night), Bildformate, automatische Belichtung und „Render & save“
# nach ~/Pictures/Amphion mit Zeitstempel. Vor dem Speichern zählt /v1/plugin/nutzen (Abo), ohne Netz wird trotzdem gerendert.
import math
import os
import tempfile
import time
import bpy
from bpy.props import EnumProperty
from . import cloud, materialien, szene
from .kern import bilder_ordner, eevee_name, modell_objekte, setze, zeigen

VORGABEN = [
    ('PREVIEW', 'Preview', 'EEVEE, a few seconds: check light and camera'),
    ('FINAL', 'Final', 'Cycles path tracing with denoising: the finished image'),
    ('CLAY', 'White model', 'Everything white, soft shadows: the classic model photo'),
    ('NIGHT', 'Night', 'Blue hour, glowing windows'),
]
FORMATE = [
    ('HD', 'Full HD 1920×1080', '', 1920, 1080),
    ('4K', '4K 3840×2160', '', 3840, 2160),
    ('A3', 'A3 landscape 300 dpi', '4961×3508 pixels, prints sharp on A3', 4961, 3508),
    ('A3_150', 'A3 landscape 150 dpi', '2480×1754 pixels, good for screens and quick prints', 2480, 1754),
    ('INSTA', 'Instagram 4:5', '1080×1350 portrait', 1080, 1350),
    ('SQUARE', 'Square 2048', '2048×2048', 2048, 2048),
]

_letztes = {'pfad': ''}


def farbe(szene):
    # AgX (4.0+) oder Filmic, leichter Kontrast
    vs = szene.view_settings
    for t in ('AgX', 'Filmic'):
        if setze(vs, 'view_transform', t):
            break
    for look in ('AgX - Medium High Contrast', 'Medium High Contrast', 'AgX - Base Contrast', 'None'):
        if setze(vs, 'look', look):
            break
    setze(szene.display_settings, 'display_device', 'sRGB')


def gpu(szene):
    # Cycles auf der Grafikkarte, wenn es eine gibt (Metal, OptiX, CUDA, HIP, oneAPI); sonst CPU
    try:
        pr = bpy.context.preferences.addons['cycles'].preferences
    except KeyError:
        return 'CPU'
    for typ in ('OPTIX', 'CUDA', 'METAL', 'HIP', 'ONEAPI'):
        try:
            pr.compute_device_type = typ
        except TypeError:
            continue
        try:
            pr.get_devices()
        except Exception:
            continue
        geraete = [d for d in pr.devices if d.type == typ]
        if geraete:
            for d in pr.devices:
                d.use = d.type == typ
            szene.cycles.device = 'GPU'
            return typ
    pr.compute_device_type = 'NONE'
    szene.cycles.device = 'CPU'
    return 'CPU'


def _eevee(szene, proben=48):
    szene.render.engine = eevee_name(szene)
    e = szene.eevee
    setze(e, 'taa_render_samples', proben)
    # EEVEE Next (4.2+): Raytracing, weiche Schatten; Legacy: AO, Spiegelungen, weiche Schatten
    setze(e, 'use_raytracing', True)
    setze(e, 'ray_tracing_method', 'SCREEN')
    setze(e, 'use_shadows', True)
    setze(e, 'shadow_ray_count', 2)
    setze(e, 'shadow_step_count', 8)
    setze(e, 'use_fast_gi', True)
    setze(e, 'fast_gi_method', 'GLOBAL_ILLUMINATION')
    setze(e, 'use_gtao', True)
    setze(e, 'gtao_distance', 1.5)
    setze(e, 'use_ssr', True)
    setze(e, 'use_ssr_refraction', True)
    setze(e, 'use_soft_shadows', True)
    setze(e, 'shadow_cascade_size', '4096')
    setze(e, 'shadow_cube_size', '2048')
    setze(e, 'volumetric_tile_size', '8')


def _cycles(szene, proben=256, schwelle=0.02):
    szene.render.engine = 'CYCLES'
    c = szene.cycles
    gpu(szene)
    c.samples = proben
    setze(c, 'use_adaptive_sampling', True)
    setze(c, 'adaptive_threshold', schwelle)
    setze(c, 'use_denoising', True)
    setze(c, 'denoiser', 'OPENIMAGEDENOISE')
    setze(c, 'denoising_input_passes', 'RGB_ALBEDO_NORMAL')
    setze(c, 'max_bounces', 8)
    setze(c, 'diffuse_bounces', 4)
    setze(c, 'glossy_bounces', 4)
    setze(c, 'transmission_bounces', 8)
    setze(c, 'transparent_max_bounces', 16)
    setze(c, 'caustics_reflective', False)
    setze(c, 'caustics_refractive', False)
    setze(c, 'sample_clamp_indirect', 10.0)
    setze(c, 'blur_glossy', 1.0)
    setze(c, 'use_light_tree', True)
    setze(szene.render, 'use_persistent_data', True)


def vorgabe(context, art):
    sz = context.scene
    st = sz.amphion
    context.view_layer.material_override = None if art != 'CLAY' else materialien.material('ton')
    alt = st.stimmung
    st.stimmung = 'NIGHT' if art == 'NIGHT' else 'DAY'
    if st.stimmung != alt or not sz.objects.get('Amphion Sun'):
        szene.licht(sz)
    if art == 'PREVIEW':
        _eevee(sz)
    elif art == 'FINAL':
        _cycles(sz, 256)
    elif art == 'CLAY':
        _cycles(sz, 128, 0.03)
    elif art == 'NIGHT':
        _cycles(sz, 384, 0.02)
    farbe(sz)
    st['vorgabe'] = art
    if not sz.camera and modell_objekte(sz):
        szene.kamera(context, st.kamera)
    return dict((v[0], v[1]) for v in VORGABEN)[art]


def format_setzen(context, art):
    sz = context.scene
    _, _, _, w, h = next(f for f in FORMATE if f[0] == art)
    sz.render.resolution_x, sz.render.resolution_y = w, h
    sz.render.resolution_percentage = 100
    sz.render.pixel_aspect_x = sz.render.pixel_aspect_y = 1
    sz.amphion['format'] = art
    kam = sz.objects.get('Amphion Camera')
    if kam and kam.get('amphion_kamera') not in (None, 'VIEW'):
        szene.kamera(context, kam['amphion_kamera'])


def belichtung(sz, ziel=1.1, anteil=92, grenze=(-8.0, 8.0)):
    # Automatische Belichtung: kleines Probebild (EXR, linear); das helle Perzentil (weiße Fassaden, Himmel) wird auf „ziel“
    # gelegt, so bleiben weiße Modelle weiß statt grau (ein Mittelwert würde helle Szenen abdunkeln)
    import numpy as np
    r = sz.render
    alt = dict(x=r.resolution_x, y=r.resolution_y, p=r.resolution_percentage, pfad=r.filepath, fmt=r.image_settings.file_format,
               tief=r.image_settings.color_depth, exp=sz.view_settings.exposure)
    alt_proben = sz.cycles.samples if r.engine == 'CYCLES' else getattr(sz.eevee, 'taa_render_samples', 16)
    alt_dn = getattr(sz.cycles, 'use_denoising', False)
    tmp = os.path.join(tempfile.gettempdir(), 'amphion_belichtung_%d.exr' % os.getpid())
    try:
        f = 160 / max(r.resolution_x, 1)
        r.resolution_x, r.resolution_y = 160, max(16, int(r.resolution_y * f))
        r.resolution_percentage = 100
        r.image_settings.file_format = 'OPEN_EXR'
        r.filepath = tmp
        if r.engine == 'CYCLES':
            sz.cycles.samples = 12
            sz.cycles.use_denoising = False
        else:
            setze(sz.eevee, 'taa_render_samples', 4)
        bpy.ops.render.render(write_still=True)
        bild = bpy.data.images.load(tmp, check_existing=False)
        px = np.empty(len(bild.pixels), dtype=np.float32)
        bild.pixels.foreach_get(px)
        bpy.data.images.remove(bild)
        px = px.reshape(-1, 4)
        hell = px[:, 0] * 0.2126 + px[:, 1] * 0.7152 + px[:, 2] * 0.0722
        if sz.render.film_transparent:
            hell = hell[px[:, 3] > 0.5]
        if not len(hell):
            return alt['exp']
        hoch = max(float(np.percentile(hell, anteil)), 1e-4)
        wert = max(grenze[0], min(grenze[1], math.log2(ziel / hoch)))
    except Exception as e:
        print('Amphion Belichtung', e)
        wert = alt['exp']
    finally:
        r.resolution_x, r.resolution_y, r.resolution_percentage = alt['x'], alt['y'], alt['p']
        r.filepath, r.image_settings.file_format = alt['pfad'], alt['fmt']
        setze(r.image_settings, 'color_depth', alt['tief'])
        if r.engine == 'CYCLES':
            sz.cycles.samples = alt_proben
            sz.cycles.use_denoising = alt_dn
        else:
            setze(sz.eevee, 'taa_render_samples', alt_proben)
        try:
            os.remove(tmp)
        except OSError:
            pass
    sz.view_settings.exposure = round(wert, 2)
    return wert


def _dateiname(sz):
    blend = os.path.splitext(os.path.basename(bpy.data.filepath))[0] or 'Render'
    art = sz.amphion.get('vorgabe', 'PREVIEW').title()
    return os.path.join(bilder_ordner(), 'Amphion_%s_%s_%s.png' % (blend, art, time.strftime('%Y%m%d_%H%M%S')))


def _png(sz):
    s = sz.render.image_settings
    s.file_format = 'PNG'
    s.color_mode = 'RGBA' if sz.render.film_transparent else 'RGB'
    s.color_depth = '8'
    setze(s, 'compression', 30)


def vorbereiten(context):
    sz = context.scene
    if not sz.camera:
        if not modell_objekte(sz):
            return 'Import a model first'
        szene.einrichten(context)
    if 'vorgabe' not in sz.amphion:
        vorgabe(context, 'PREVIEW')
    if sz.amphion.auto_belichtung:
        st = sz.amphion
        if st.stimmung == 'NIGHT':
            belichtung(sz, 1.6, 99, (-2.0, 3.0))
        elif st.get('vorgabe') == 'CLAY' or st.licht_art == 'STUDIO':
            belichtung(sz, 1.5, 90, (-1.0, 1.2))
        else:
            # Tageslicht ist kalibriert: nur nachregeln (Blick nur auf Gras würde sonst überbelichten)
            belichtung(sz, 1.1, 92, (-1.5, 0.3))
    _png(sz)
    return ''


def speichern(sz):
    pfad = _dateiname(sz)
    bild = bpy.data.images.get('Render Result')
    if bild is None:
        return ''
    bild.save_render(pfad, scene=sz)
    _letztes['pfad'] = pfad
    return pfad


def letztes_bild():
    p = _letztes['pfad']
    return p if p and os.path.isfile(p) else ''


class AMPHION_OT_preset(bpy.types.Operator):
    bl_idname = 'amphion.render_preset'
    bl_label = 'Render preset'
    bl_description = 'Set render engine, quality and look'
    bl_options = {'REGISTER', 'UNDO'}
    art: EnumProperty(items=[v[:3] for v in VORGABEN])

    @classmethod
    def description(cls, context, props):
        return dict((v[0], v[2]) for v in VORGABEN).get(props.art, cls.bl_description)

    def execute(self, context):
        self.report({'INFO'}, 'Render preset: ' + vorgabe(context, self.art))
        return {'FINISHED'}


class AMPHION_OT_format(bpy.types.Operator):
    bl_idname = 'amphion.resolution'
    bl_label = 'Image size'
    bl_options = {'REGISTER', 'UNDO'}
    art: EnumProperty(items=[f[:3] for f in FORMATE])

    def execute(self, context):
        format_setzen(context, self.art)
        return {'FINISHED'}


class AMPHION_OT_render_save(bpy.types.Operator):
    bl_idname = 'amphion.render_save'
    bl_label = 'Render & save'
    bl_description = 'Render the image and save it as PNG in Pictures/Amphion'

    _laeuft = False

    def _pruefen(self):
        ok, nachricht = cloud.nutzen('blender')
        if not ok:
            bpy.ops.amphion.subscribe_dialog('INVOKE_DEFAULT')
            return False
        if nachricht:
            self.report({'INFO'}, nachricht)
        return True

    def execute(self, context):
        # Blockierend (Hintergrundmodus, Skripte)
        if not self._pruefen():
            return {'CANCELLED'}
        fehler = vorbereiten(context)
        if fehler:
            self.report({'ERROR'}, fehler)
            return {'CANCELLED'}
        bpy.ops.render.render()
        pfad = speichern(context.scene)
        self.report({'INFO'}, 'Saved ' + pfad)
        zeigen(pfad)
        return {'FINISHED'}

    def invoke(self, context, event):
        # Im Fenster: Renderfenster mit Fortschritt, Speichern nach Abschluss über einen Timer im Hauptthread
        if bpy.app.background:
            return self.execute(context)
        if not self._pruefen():
            return {'CANCELLED'}
        fehler = vorbereiten(context)
        if fehler:
            self.report({'ERROR'}, fehler)
            return {'CANCELLED'}
        sz = context.scene

        def fertig(*_):
            _abmelden()
            bpy.app.timers.register(lambda: _nach_render(sz.name), first_interval=0.2)

        def abbruch(*_):
            _abmelden()

        def _abmelden():
            for liste, f in ((bpy.app.handlers.render_complete, fertig), (bpy.app.handlers.render_cancel, abbruch)):
                if f in liste:
                    liste.remove(f)

        bpy.app.handlers.render_complete.append(fertig)
        bpy.app.handlers.render_cancel.append(abbruch)
        bpy.ops.render.render('INVOKE_DEFAULT')
        return {'FINISHED'}


def _nach_render(name):
    sz = bpy.data.scenes.get(name)
    if sz:
        pfad = speichern(sz)
        if pfad:
            zeigen(pfad)
    return None


class AMPHION_OT_open_folder(bpy.types.Operator):
    bl_idname = 'amphion.open_folder'
    bl_label = 'Open renders folder'
    bl_description = 'Open Pictures/Amphion'

    def execute(self, context):
        zeigen(letztes_bild() or bilder_ordner())
        return {'FINISHED'}
