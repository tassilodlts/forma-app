# Architekturmaterialien als prozedurale Knoten (ohne Texturen, ohne Downloads) und Zuordnung über Schlüsselwörter
# aus Material-, Layer- und Objektnamen (englisch, deutsch, spanisch, französisch, italienisch).
import re
import unicodedata
import bpy
from .kern import eingang, setze

# Reihenfolge zählt: Rahmen vor Glas („Window frame“), Glas vor Putz („Fassade Glas“). '^' = nur Wortanfang
KATEGORIEN = [
    ('rahmen', ['frame', 'rahmen', 'marco', 'carpinter', 'mullion', 'pfosten', 'riegel', '^profil', 'sash', 'menuiserie', 'serramento', 'telaio']),
    ('glas', ['glass', 'glas', 'vidrio', 'cristal', 'glazing', 'verglas', 'window', 'fenster', 'ventana', 'acristal', 'vitr', 'verre', 'vetro', 'skylight', 'oberlicht']),
    ('wasser', ['water', 'wasser', 'agua', 'pool', 'pond', 'lake', 'teich', 'piscina', 'estanque', 'eau', 'acqua', 'river', 'fluss']),
    ('gras', ['grass', 'gras', 'rasen', 'lawn', 'cesped', 'turf', 'green', 'vegetation', 'planting', 'gruen', 'jardin', 'garden', 'garten', 'herbe', 'prato', 'pelouse']),
    ('gelaende', ['terrain', '^topo', 'gelaende', 'terreno', 'landscape', 'landschaft', '^soil', '^earth', '^erde', 'tierra', '^site', '^dgm', '^dtm', '^dem', 'sol naturel']),
    ('ziegel', ['brick', 'ziegel', 'klinker', 'ladrillo', 'backstein', 'mauerwerk', 'brique', 'mattone', 'masonry']),
    ('holz', ['wood', 'holz', 'madera', 'timber', 'oak', 'eiche', 'roble', 'pine', 'kiefer', '^pino', 'larch', 'laerche', 'parquet', 'parkett', 'plywood', '^clt', 'walnut', 'nogal', 'nuss', 'birch', 'birke', 'abedul', 'fresno', 'cedar', 'zeder', 'teak', 'bamboo', 'bambus', 'bois', 'legno', 'cladding wood']),
    ('metall', ['metal', 'metall', 'steel', 'stahl', 'acero', '^alu', 'zinc', 'zink', 'copper', 'kupfer', 'cobre', 'brass', 'messing', 'chrome', '^iron', 'eisen', 'hierro', 'corten', 'inox', 'railing', 'gelaender', 'barandilla', 'acier', 'acciaio']),
    ('stein', ['stone', 'stein', 'piedra', 'granit', 'marble', 'marmor', 'marmol', 'travertin', 'limestone', 'kalkstein', '^tile', 'fliese', 'azulejo', 'baldosa', 'pierre', 'pietra', 'paving', 'pflaster', 'pavimento', 'terrazzo']),
    ('beton', ['concrete', 'beton', 'hormigon', 'cement', 'zement', 'cemento', 'screed', 'estrich', '^slab', 'forjado', 'decke', 'calcestruzzo', 'dalle']),
    ('putz', ['plaster', 'putz', 'yeso', 'enlucido', 'render', 'stucco', 'stuck', 'wall', 'wand', 'muro', 'pared', 'white', 'weiss', 'blanco', 'paint', 'farbe', 'pintura', 'facade', 'fassade', 'fachada', 'drywall', 'gips', 'enduit', 'intonaco']),
]

NAMEN = {'putz': 'White plaster', 'beton': 'Concrete', 'glas': 'Glass', 'holz': 'Wood', 'metall': 'Metal', 'rahmen': 'Dark metal',
         'ziegel': 'Brick', 'gras': 'Grass', 'wasser': 'Water', 'gelaende': 'Terrain', 'stein': 'Stone', 'boden': 'Ground', 'ton': 'Clay',
         'studio': 'Studio floor'}


def normal(text):
    # Kleinbuchstaben, Umlaute als ae/oe/ue, Akzente weg
    t = str(text or '').lower().replace('ä', 'ae').replace('ö', 'oe').replace('ü', 'ue').replace('ß', 'ss')
    return ''.join(c for c in unicodedata.normalize('NFKD', t) if not unicodedata.combining(c))


def erkennen(*texte):
    # Materialart aus Namen; None, wenn nichts passt
    t = normal(' '.join(str(x) for x in texte if x))
    woerter = re.split(r'[^a-z0-9]+', t)
    for art, schluessel in KATEGORIEN:
        for s in schluessel:
            if s.startswith('^'):
                if any(w.startswith(s[1:]) for w in woerter):
                    return art
            elif s in t:
                return art
    return None


# --- kleiner Knotenbaukasten -------------------------------------------------------------------------------------------
class Baum:
    def __init__(self, mat):
        mat.use_nodes = True
        self.nt = mat.node_tree
        self.nt.nodes.clear()
        self.x = -1200

    def k(self, typ, **werte):
        n = self.nt.nodes.new(typ)
        n.location = (self.x, 0)
        self.x += 180
        for a, v in werte.items():
            setze(n, a, v)
        return n

    def v(self, a, b):
        self.nt.links.new(a, b)

    def mathe(self, op, a, b=None, wert=None):
        n = self.k('ShaderNodeMath', operation=op)
        for i, e in enumerate((a, b)):
            if e is None:
                if wert is not None and i == 1:
                    n.inputs[1].default_value = wert
                continue
            if isinstance(e, (int, float)):
                n.inputs[i].default_value = e
            else:
                self.v(e, n.inputs[i])
        return n.outputs[0]

    def vek(self, op, a, b=None, faktor=None):
        n = self.k('ShaderNodeVectorMath', operation=op)
        self.v(a, n.inputs[0])
        if b is not None:
            self.v(b, n.inputs[1])
        if faktor is not None:
            if isinstance(faktor, (int, float)):
                n.inputs['Scale'].default_value = faktor
            else:
                self.v(faktor, n.inputs['Scale'])
        return n.outputs[0]


def _bsdf(b, farbe, rauh, metall=0.0):
    p = b.k('ShaderNodeBsdfPrincipled')
    eingang(p, 'Base Color', (*farbe, 1))
    eingang(p, 'Roughness', rauh)
    eingang(p, 'Metallic', metall)
    return p


def _rauschen(b, skala, detail=6.0, rauheit=0.6):
    tc = b.k('ShaderNodeTexCoord')
    n = b.k('ShaderNodeTexNoise')
    b.v(tc.outputs['Object'], n.inputs['Vector'])
    eingang(n, 'Scale', skala)
    eingang(n, 'Detail', detail)
    eingang(n, 'Roughness', rauheit)
    return n


def _rampe(b, fac, f1, f2, a=0.35, e=0.65):
    r = b.k('ShaderNodeValToRGB')
    el = r.color_ramp.elements
    el[0].position, el[0].color = a, (*f1, 1)
    el[1].position, el[1].color = e, (*f2, 1)
    b.v(fac, r.inputs['Fac'])
    return r.outputs['Color']


def _relief(b, hoehe, staerke, p, abstand=0.02):
    bu = b.k('ShaderNodeBump')
    eingang(bu, 'Strength', staerke)
    eingang(bu, 'Distance', abstand)
    b.v(hoehe, bu.inputs['Height'])
    b.v(bu.outputs['Normal'], p.inputs['Normal'])


def _aus(b, shader):
    o = b.k('ShaderNodeOutputMaterial')
    b.v(shader, o.inputs['Surface'])


def _rauh_farbig(b, grundfarbe, dunkler, rauh, skala, relief, metall=0.0):
    n = _rauschen(b, skala)
    p = _bsdf(b, grundfarbe, rauh, metall)
    b.v(_rampe(b, n.outputs['Fac'], dunkler, grundfarbe), p.inputs['Base Color'])
    if relief:
        _relief(b, n.outputs['Fac'], relief, p)
    _aus(b, p.outputs[0])
    return p


def _wand_koordinaten(b):
    # 2D-Koordinaten für Ziegel: Wände (u = Länge, v = Höhe), waagrechte Flächen (x, y)
    tc = b.k('ShaderNodeTexCoord')
    s = b.k('ShaderNodeSeparateXYZ')
    b.v(tc.outputs['Object'], s.inputs[0])
    nrm = b.k('ShaderNodeSeparateXYZ')
    b.v(tc.outputs['Normal'], nrm.inputs[0])
    ax = b.mathe('ABSOLUTE', nrm.outputs['X'])
    ay = b.mathe('ABSOLUTE', nrm.outputs['Y'])
    az = b.mathe('ABSOLUTE', nrm.outputs['Z'])
    u = b.mathe('ADD', b.mathe('MULTIPLY', s.outputs['X'], ay), b.mathe('MULTIPLY', s.outputs['Y'], ax))
    wand = b.k('ShaderNodeCombineXYZ')
    b.v(u, wand.inputs['X'])
    b.v(s.outputs['Z'], wand.inputs['Y'])
    flach = b.k('ShaderNodeCombineXYZ')
    b.v(s.outputs['X'], flach.inputs['X'])
    b.v(s.outputs['Y'], flach.inputs['Y'])
    oben = b.mathe('GREATER_THAN', az, 0.7)
    unten = b.mathe('SUBTRACT', 1.0, oben)
    return b.vek('ADD', b.vek('SCALE', wand.outputs[0], faktor=unten), b.vek('SCALE', flach.outputs[0], faktor=oben))


def _glas(b, mat):
    # Dünnes Architekturglas: Fresnel-Mischung aus Durchsicht und Spiegelung, Schattenstrahlen gehen durch (Innenräume hell),
    # Knoten „nacht“ lässt die Scheiben abends warm leuchten
    lw = b.k('ShaderNodeLayerWeight')
    eingang(lw, 'Blend', 0.25)
    tr = b.k('ShaderNodeBsdfTransparent')
    eingang(tr, 'Color', (0.78, 0.86, 0.86, 1))
    gl = b.k('ShaderNodeBsdfGlossy')
    eingang(gl, 'Roughness', 0.03)
    eingang(gl, 'Color', (0.9, 0.95, 0.97, 1))
    m = b.k('ShaderNodeMixShader')
    b.v(lw.outputs['Fresnel'], m.inputs[0])
    b.v(tr.outputs[0], m.inputs[1])
    b.v(gl.outputs[0], m.inputs[2])
    em = b.k('ShaderNodeEmission')
    eingang(em, 'Color', (1.0, 0.62, 0.32, 1))
    nacht = b.k('ShaderNodeValue', name='nacht', label='Night glow')
    nacht.outputs[0].default_value = 0.0
    b.v(nacht.outputs[0], em.inputs['Strength'])
    add = b.k('ShaderNodeAddShader')
    b.v(m.outputs[0], add.inputs[0])
    b.v(em.outputs[0], add.inputs[1])
    lp = b.k('ShaderNodeLightPath')
    t2 = b.k('ShaderNodeBsdfTransparent')
    m2 = b.k('ShaderNodeMixShader')
    b.v(lp.outputs['Is Shadow Ray'], m2.inputs[0])
    b.v(add.outputs[0], m2.inputs[1])
    b.v(t2.outputs[0], m2.inputs[2])
    _aus(b, m2.outputs[0])
    setze(mat, 'blend_method', 'HASHED')
    setze(mat, 'shadow_method', 'HASHED')
    setze(mat, 'surface_render_method', 'DITHERED')
    setze(mat, 'use_transparent_shadow', True)
    mat.diffuse_color = (0.6, 0.75, 0.8, 0.35)


def _ziegel(b):
    vec = _wand_koordinaten(b)
    br = b.k('ShaderNodeTexBrick', offset=0.5, offset_frequency=2)
    b.v(vec, br.inputs['Vector'])
    eingang(br, 'Color1', (0.42, 0.15, 0.07, 1))
    eingang(br, 'Color2', (0.33, 0.11, 0.05, 1))
    eingang(br, 'Mortar', (0.55, 0.53, 0.5, 1))
    eingang(br, 'Scale', 1.0)
    eingang(br, 'Mortar Size', 0.01)
    eingang(br, 'Brick Width', 0.25)
    eingang(br, 'Row Height', 0.0815)
    eingang(br, 'Bias', 0.0)
    p = _bsdf(b, (0.4, 0.15, 0.07), 0.85)
    b.v(br.outputs['Color'], p.inputs['Base Color'])
    _relief(b, b.mathe('SUBTRACT', 1.0, br.outputs['Fac']), 0.35, p, 0.005)
    _aus(b, p.outputs[0])


def _holz(b):
    # Senkrechte Bretter (14 cm) mit Fugen, Farbunterschied je Brett und feiner Maserung entlang der Bretter
    vec = _wand_koordinaten(b)
    sep = b.k('ShaderNodeSeparateXYZ')
    b.v(vec, sep.inputs[0])
    brett = b.mathe('FLOOR', b.mathe('DIVIDE', sep.outputs['X'], 0.14))
    fuge = b.mathe('GREATER_THAN', b.mathe('FRACT', b.mathe('DIVIDE', sep.outputs['X'], 0.14)), 0.965)
    zufall = b.k('ShaderNodeTexWhiteNoise', noise_dimensions='1D')
    b.v(brett, zufall.inputs['W'])
    maser = b.k('ShaderNodeTexNoise')
    streck = b.k('ShaderNodeCombineXYZ')
    b.v(b.mathe('MULTIPLY', sep.outputs['X'], 60.0), streck.inputs['X'])
    b.v(b.mathe('MULTIPLY', sep.outputs['Y'], 1.5), streck.inputs['Y'])
    b.v(b.mathe('ADD', brett, 0.0), streck.inputs['Z'])
    b.v(streck.outputs[0], maser.inputs['Vector'])
    eingang(maser, 'Scale', 1.0)
    eingang(maser, 'Detail', 4.0)
    mix = b.mathe('ADD', b.mathe('MULTIPLY', zufall.outputs['Value'], 0.6), b.mathe('MULTIPLY', maser.outputs['Fac'], 0.4))
    farbe = _rampe(b, mix, (0.26, 0.15, 0.075), (0.45, 0.29, 0.15), 0.25, 0.85)
    dunkel = b.k('ShaderNodeMixRGB', blend_type='MULTIPLY')
    b.v(fuge, dunkel.inputs['Fac'])
    b.v(farbe, dunkel.inputs['Color1'])
    eingang(dunkel, 'Color2', (0.25, 0.25, 0.25, 1))
    p = _bsdf(b, (0.4, 0.26, 0.13), 0.6)
    b.v(dunkel.outputs[0], p.inputs['Base Color'])
    _relief(b, b.mathe('SUBTRACT', 1.0, fuge), 0.3, p, 0.004)
    _aus(b, p.outputs[0])


def material(art):
    # Gemeinsames Material je Art („Amphion Concrete“); wird bei erneutem Aufruf wiederverwendet
    name = 'Amphion ' + NAMEN.get(art, art)
    mat = bpy.data.materials.get(name)
    if mat:
        return mat
    mat = bpy.data.materials.new(name)
    mat['amphion_art'] = art
    b = Baum(mat)
    if art == 'glas':
        _glas(b, mat)
        return mat
    if art == 'ziegel':
        _ziegel(b)
    elif art == 'holz':
        _holz(b)
    elif art == 'beton':
        _rauh_farbig(b, (0.46, 0.45, 0.43), (0.34, 0.33, 0.32), 0.8, 6.0, 0.08)
    elif art == 'putz':
        _rauh_farbig(b, (0.8, 0.79, 0.76), (0.74, 0.73, 0.7), 0.9, 30.0, 0.02)
    elif art == 'metall':
        _rauh_farbig(b, (0.62, 0.63, 0.65), (0.55, 0.56, 0.58), 0.32, 40.0, 0.0, 1.0)
    elif art == 'rahmen':
        _rauh_farbig(b, (0.05, 0.05, 0.055), (0.04, 0.04, 0.045), 0.45, 40.0, 0.0, 0.7)
    elif art == 'gras':
        _rauh_farbig(b, (0.1, 0.18, 0.045), (0.06, 0.12, 0.03), 0.95, 12.0, 0.25)
    elif art == 'wasser':
        p = _rauh_farbig(b, (0.015, 0.04, 0.05), (0.01, 0.03, 0.04), 0.03, 2.5, 0.05)
        eingang(p, 'IOR', 1.33)
    elif art == 'gelaende':
        _rauh_farbig(b, (0.33, 0.28, 0.21), (0.24, 0.2, 0.15), 1.0, 4.0, 0.2)
    elif art == 'stein':
        _rauh_farbig(b, (0.62, 0.58, 0.52), (0.52, 0.48, 0.43), 0.55, 3.0, 0.03)
    elif art == 'boden':
        _rauh_farbig(b, (0.42, 0.41, 0.39), (0.36, 0.35, 0.34), 0.9, 1.5, 0.0)
    elif art == 'studio':
        _rauh_farbig(b, (0.82, 0.82, 0.82), (0.8, 0.8, 0.8), 0.8, 2.0, 0.0)
    else:   # 'ton' (Weißmodell)
        _aus(b, _bsdf(b, (0.8, 0.8, 0.78), 0.65).outputs[0])
    farbe = {'beton': (0.46, 0.45, 0.43), 'holz': (0.42, 0.26, 0.13), 'metall': (0.6, 0.6, 0.62), 'rahmen': (0.05, 0.05, 0.05),
             'gras': (0.1, 0.18, 0.05), 'wasser': (0.02, 0.05, 0.07), 'gelaende': (0.33, 0.28, 0.21), 'ziegel': (0.4, 0.15, 0.07),
             'stein': (0.6, 0.56, 0.5)}.get(art, (0.8, 0.8, 0.78))
    mat.diffuse_color = (*farbe, 1)
    return mat


def eigenes(name, farbe, transparenz=0.0):
    # Unbekanntes Rhino-Material: Farbe und Transparenz aus der Datei übernehmen
    mat = bpy.data.materials.get(name)
    if mat:
        return mat
    if transparenz > 0.3:
        return material('glas')
    mat = bpy.data.materials.new(name)
    b = Baum(mat)
    _aus(b, _bsdf(b, farbe, 0.6).outputs[0])
    mat.diffuse_color = (*farbe, 1)
    return mat


def srgb_linear(c):
    c = c / 255.0 if c > 1.0 else c
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def zuordnen(objekte, modus='SMART'):
    # Materialien der importierten Objekte ersetzen: SMART = erkannte Namen und leere Plätze, ALL = alles (Unbekanntes weiß), KEEP = nichts
    if modus == 'KEEP':
        return 0
    n = 0
    for ob in objekte:
        if ob.type != 'MESH':
            continue
        sammlung = ob.users_collection[0].name if ob.users_collection else ''
        if not ob.material_slots:
            ob.data.materials.append(material(erkennen(ob.name, sammlung) or 'putz'))
            n += 1
            continue
        for slot in ob.material_slots:
            alt = slot.material
            art = erkennen(alt.name if alt else '', ob.name, sammlung)
            if alt and alt.get('amphion_art'):
                continue
            if art or alt is None or modus == 'ALL' or _schlicht(alt):
                neu = material(art or 'putz')
                if slot.link == 'OBJECT':
                    slot.material = neu
                else:
                    ob.data.materials[slot.slot_index] = neu
                n += 1
    return n


def _schlicht(mat):
    # Ein Material ohne Bildtexturen in Standardgrau/-weiß ersetzen wir durch Putz (Exporte bringen oft „Material.001“ in Grau)
    if not mat.use_nodes or not mat.node_tree:
        return True
    if any(n.type == 'TEX_IMAGE' for n in mat.node_tree.nodes):
        return False
    p = next((n for n in mat.node_tree.nodes if n.type == 'BSDF_PRINCIPLED'), None)
    if not p:
        return False
    r, g, bl, _ = p.inputs['Base Color'].default_value
    return max(r, g, bl) - min(r, g, bl) < 0.03 and not p.inputs['Base Color'].is_linked
