# „Import model“: ein Knopf für .3dm, .obj, .fbx, .glb/.gltf, .stl, .dae und .ifc (mit Bonsai). Danach Einheiten, Transformationen,
# Zusammenfassen, Verschweißen, Glätten, Sammlungen und Architekturmaterialien, damit das Modell sofort renderfertig ist.
import os
import bpy
from bpy.props import BoolProperty, EnumProperty, StringProperty
from bpy_extras.io_utils import ImportHelper
from mathutils import Matrix, Vector
from . import import_3dm, materialien
from .kern import glatt, grenzen, verschweissen

ENDUNGEN = '*.3dm;*.obj;*.fbx;*.glb;*.gltf;*.stl;*.dae;*.ifc;*.ply'
EINHEITEN = [('AUTO', 'Auto-detect', 'Guess mm, cm or m from the model size'), ('MM', 'Millimetres', ''), ('CM', 'Centimetres', ''),
             ('M', 'Metres', ''), ('IN', 'Inches', ''), ('FT', 'Feet', '')]
FAKTOR = {'MM': 0.001, 'CM': 0.01, 'M': 1.0, 'IN': 0.0254, 'FT': 0.3048}


def _op(*namen):
    # Ersten vorhandenen Operator liefern (wm.obj_import ab 3.3/4.0, import_scene.obj davor)
    for n in namen:
        modul, name = n.split('.')
        gruppe = getattr(bpy.ops, modul, None)
        if gruppe is not None and hasattr(gruppe, name):
            try:
                getattr(gruppe, name).get_rna_type()
                return getattr(gruppe, name)
            except (KeyError, AttributeError):
                continue
    return None


def einheit_raten(groesse):
    # Größte Ausdehnung in Dateieinheiten → Faktor in Meter. Gebäude sind 3 bis 500 m groß
    if groesse > 5000:
        return 0.001, 'mm'
    if groesse > 800:
        return 0.01, 'cm'
    return 1.0, 'm'


class AMPHION_OT_import(bpy.types.Operator, ImportHelper):
    bl_idname = 'amphion.import_model'
    bl_label = 'Import model'
    bl_description = 'Import a 3D model (Rhino, OBJ, FBX, glTF, STL, Collada, IFC) and prepare it for rendering'
    bl_options = {'REGISTER', 'UNDO'}

    filter_glob: StringProperty(default=ENDUNGEN, options={'HIDDEN'})
    einheit: EnumProperty(name='Units', items=EINHEITEN, default='AUTO',
                          description='Units of the file. Rhino, FBX and glTF files carry their own units')
    zusammen: BoolProperty(name='Merge by layer', default=True,
                           description='One object per layer or material instead of thousands of small ones (much faster)')
    zentrieren: BoolProperty(name='Move to origin', default=False,
                             description='Centre the model on the world origin, base at height 0')
    materialien_modus: EnumProperty(name='Materials', default='SMART', items=[
        ('SMART', 'Smart', 'Architectural materials from layer and material names, white plaster for plain or missing materials'),
        ('ALL', 'Replace all', 'Architectural materials where a name matches, white plaster for everything else'),
        ('KEEP', 'Keep original', 'Keep the materials of the file')])
    versteckte: BoolProperty(name='Include hidden layers', default=False)

    def draw(self, context):
        lay = self.layout
        lay.prop(self, 'einheit')
        lay.prop(self, 'materialien_modus')
        lay.prop(self, 'zusammen')
        lay.prop(self, 'zentrieren')
        lay.prop(self, 'versteckte')

    def execute(self, context):
        pfad = self.filepath
        if not os.path.isfile(pfad):
            self.report({'ERROR'}, 'File not found')
            return {'CANCELLED'}
        try:
            neu, hinweis = importieren(context, pfad, self.einheit, self.zusammen, self.zentrieren, self.materialien_modus, self.versteckte)
        except RuntimeError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        self.report({'INFO'}, hinweis)
        return {'FINISHED'}


def importieren(context, pfad, einheit='AUTO', zusammen=True, zentrieren=False, mat_modus='SMART', versteckte=False):
    endung = os.path.splitext(pfad)[1].lower()
    stamm = os.path.splitext(os.path.basename(pfad))[0]
    szene = context.scene
    wurzel = bpy.data.collections.new(stamm)
    szene.collection.children.link(wurzel)
    if endung == '.3dm':
        try:
            erg, skala = import_3dm.lesen(pfad, zusammen, versteckte)
        except RuntimeError as e:
            bpy.data.collections.remove(wurzel)
            if str(e) == 'rhino3dm':
                raise RuntimeError('Rhino import needs the rhino3dm module, which is not available for this Blender/Python version. '
                                   'In Rhino use File > Export Selected as OBJ or FBX and import that file.')
            raise RuntimeError('This .3dm file could not be read (damaged or newer than Rhino 8).')
        info = ''
        if not skala:
            groesse = max((max(c) - min(c) for c in zip(*[p for t in erg.teile.values() for p in t['pkt']])), default=1)
            skala, info = einheit_raten(groesse)
        if einheit != 'AUTO':
            skala = FAKTOR[einheit]
        neu, _ = import_3dm.bauen(erg, skala, wurzel, zentrieren)
        for ob in neu:
            ob.select_set(True)
        hinweis = 'Imported %d Rhino objects as %d meshes%s' % (erg.objekte, len(neu), (', units guessed: ' + info) if info else '')
        if erg.uebersprungen:
            hinweis += ', %d curves/annotations skipped' % erg.uebersprungen
        return neu, hinweis
    vorher = set(bpy.data.objects)
    # Neue Objekte landen in der aktiven Sammlung: vorher auf die neue Wurzel umstellen
    lc = _layer_sammlung(context.view_layer.layer_collection, wurzel)
    if lc:
        context.view_layer.active_layer_collection = lc
    eigene_einheit = endung in ('.fbx', '.glb', '.gltf', '.ifc')
    try:
        if endung == '.obj':
            op = _op('wm.obj_import', 'import_scene.obj')
            op(filepath=pfad)
        elif endung == '.fbx':
            bpy.ops.import_scene.fbx(filepath=pfad)
        elif endung in ('.glb', '.gltf'):
            bpy.ops.import_scene.gltf(filepath=pfad)
        elif endung == '.stl':
            _op('wm.stl_import', 'import_mesh.stl')(filepath=pfad)
        elif endung == '.ply':
            _op('wm.ply_import', 'import_mesh.ply')(filepath=pfad)
        elif endung == '.dae':
            op = _op('wm.collada_import')
            if not op:
                raise RuntimeError('Collada (.dae) import was removed in Blender 5.0. Please export OBJ, FBX or glTF instead.')
            op(filepath=pfad)
        elif endung == '.ifc':
            op = _op('bim.load_project')
            if not op:
                raise RuntimeError('IFC needs the free Bonsai extension (Edit > Preferences > Get Extensions > Bonsai). '
                                   'Or export OBJ/FBX from your BIM tool.')
            op(filepath=pfad)
        else:
            raise RuntimeError('Unsupported file type: ' + endung)
    except RuntimeError:
        if not wurzel.all_objects:
            bpy.data.collections.remove(wurzel)
        raise
    neu = [o for o in bpy.data.objects if o not in vorher]
    netze = [o for o in neu if o.type == 'MESH']
    if not netze:
        return neu, 'Nothing to render in this file (no surfaces found)'
    # Einheiten: unitlose Formate nach Größe raten
    info = ''
    if einheit != 'AUTO':
        skala = FAKTOR[einheit]
    elif not eigene_einheit:
        g = grenzen(netze)
        skala, info = einheit_raten(max(g[1] - g[0]))
    else:
        skala = 1.0
    wurzeln = [o for o in neu if o.parent is None]
    if skala != 1.0:
        S = Matrix.Scale(skala, 4)
        for o in wurzeln:
            o.matrix_world = S @ o.matrix_world
    context.view_layer.update()
    _transformen_anwenden(context, netze)
    context.view_layer.update()
    if zusammen and len(netze) > 200:
        netze = _zusammenfassen(context, netze)
    g = grenzen(netze)
    if g and (zentrieren or ((g[0] + g[1]) / 2).length > 10000):
        d = Vector(((g[0].x + g[1].x) / 2, (g[0].y + g[1].y) / 2, g[0].z))
        for o in [o for o in neu if o.parent is None and o.name in bpy.data.objects]:
            o.location -= d
    context.view_layer.update()
    for o in netze:
        if o.data.users == 1:
            verschweissen(o.data, 0.0005)
        glatt(o.data, 30)
    materialien.zuordnen(netze, mat_modus)
    hinweis = 'Imported %d objects' % len(netze) + (', units guessed: ' + info if info else '')
    return netze, hinweis


def _layer_sammlung(lc, ziel):
    if lc.collection == ziel:
        return lc
    for k in lc.children:
        r = _layer_sammlung(k, ziel)
        if r:
            return r
    return None


def _transformen_anwenden(context, netze):
    # Drehung und Maßstab in die Netze schreiben (Lage bleibt); geteilte Netze werden nicht angefasst
    welt = {o: o.matrix_world.copy() for o in netze}
    for o in netze:
        if o.data.users != 1:
            continue
        mw = welt[o]
        loc = mw.to_translation()
        lin = mw.to_3x3().to_4x4()
        o.data.transform(lin)
        if lin.determinant() < 0:
            o.data.flip_normals()
        o.parent = None
        o.matrix_world = Matrix.Translation(loc)


def _zusammenfassen(context, netze):
    # Viele Einzelobjekte je Sammlung und erstem Material zu einem Objekt verbinden
    gruppen = {}
    for o in netze:
        if o.data.users != 1:
            continue
        mat = o.material_slots[0].material.name if o.material_slots and o.material_slots[0].material else ''
        sam = o.users_collection[0].name if o.users_collection else ''
        gruppen.setdefault((sam, mat), []).append(o)
    ergebnis = [o for o in netze if o.data.users != 1]
    for (sam, mat), obs in gruppen.items():
        if len(obs) == 1:
            ergebnis += obs
            continue
        ziel = obs[0]
        with context.temp_override(active_object=ziel, selected_editable_objects=obs, selected_objects=obs, object=ziel):
            bpy.ops.object.join()
        ziel.name = mat or sam or ziel.name
        ergebnis.append(ziel)
    return ergebnis


def menue(self, context):
    self.layout.operator(AMPHION_OT_import.bl_idname, text='Amphion model (.3dm, .obj, .fbx, .glb, .ifc)')
