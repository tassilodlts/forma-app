# „Export for 3D print“: Modell im Maßstab 1:100/1:200/1:500 in Millimetern als STL, 3MF oder OBJ (eigene Schreiber, unabhängig
# von der Blender-Version), vorher Netzprüfung: offene Kanten, zu dünne Wände für den Maßstab. Zählt als Nutzung (/v1/plugin/nutzen).
import os
import struct
import zipfile
import bmesh
import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, StringProperty
from bpy_extras.io_utils import ExportHelper
from mathutils.bvhtree import BVHTree
from . import cloud
from .kern import modell_objekte, zeigen

MASSSTAB = [('100', '1:100', 'Building model, 1 m = 10 mm'), ('200', '1:200', '1 m = 5 mm'), ('500', '1:500', 'Urban model, 1 m = 2 mm'),
            ('50', '1:50', 'Detail model, 1 m = 20 mm')]


def _dreiecke(objekte, faktor, depsgraph):
    # Alle Netze (mit Modifikatoren) als Weltdreiecke in mm
    pkt, tri = [], []
    for ob in objekte:
        ev = ob.evaluated_get(depsgraph)
        me = ev.to_mesh()
        me.calc_loop_triangles()
        mw = ob.matrix_world
        o = len(pkt)
        pkt += [tuple((mw @ v.co) * faktor) for v in me.vertices]
        tri += [(t.vertices[0] + o, t.vertices[1] + o, t.vertices[2] + o) for t in me.loop_triangles]
        ev.to_mesh_clear()
    return pkt, tri


def pruefen(objekte, wand_m, depsgraph):
    # Offene Kanten und dünne Stellen (Strahl nach innen trifft näher als wand_m) als Flächenanteil
    offen, duenn, flaeche = 0, 0.0, 0.0
    for ob in objekte:
        bm = bmesh.new()
        bm.from_object(ob, depsgraph)
        bm.transform(ob.matrix_world)
        bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=1e-5)
        offen += sum(1 for e in bm.edges if not e.is_manifold)
        bm.faces.ensure_lookup_table()
        baum = BVHTree.FromBMesh(bm)
        schritt = max(1, len(bm.faces) // 3000)
        for i in range(0, len(bm.faces), schritt):
            f = bm.faces[i]
            a = f.calc_area()
            flaeche += a
            start = f.calc_center_median() - f.normal * 1e-4
            treffer = baum.ray_cast(start, -f.normal, wand_m)
            if treffer[0] is not None and treffer[3] > 1e-5:
                duenn += a
        bm.free()
    return offen, (duenn / flaeche if flaeche else 0.0)


def stl(pfad, pkt, tri):
    with open(pfad, 'wb') as f:
        f.write(b'Amphion for Blender STL (mm)'.ljust(80, b' '))
        f.write(struct.pack('<I', len(tri)))
        for a, b, c in tri:
            pa, pb, pc = pkt[a], pkt[b], pkt[c]
            u = [pb[i] - pa[i] for i in range(3)]
            v = [pc[i] - pa[i] for i in range(3)]
            n = (u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0])
            ln = sum(x * x for x in n) ** 0.5 or 1
            f.write(struct.pack('<12fH', n[0] / ln, n[1] / ln, n[2] / ln, *pa, *pb, *pc, 0))


def obj(pfad, pkt, tri):
    with open(pfad, 'w', encoding='utf-8') as f:
        f.write('# Amphion for Blender, units: millimetres\n')
        f.writelines('v %.4f %.4f %.4f\n' % p for p in pkt)
        f.writelines('f %d %d %d\n' % (a + 1, b + 1, c + 1) for a, b, c in tri)


def dreimf(pfad, pkt, tri):
    # 3MF: Zip mit 3D/3dmodel.model (Einheit Millimeter), von allen gängigen Slicern gelesen
    modell = ['<?xml version="1.0" encoding="UTF-8"?>\n<model unit="millimeter" xml:lang="en-US" '
              'xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02">\n'
              '<metadata name="Application">Amphion for Blender</metadata>\n<resources><object id="1" type="model"><mesh><vertices>']
    modell += ['<vertex x="%.4f" y="%.4f" z="%.4f"/>' % p for p in pkt]
    modell.append('</vertices><triangles>')
    modell += ['<triangle v1="%d" v2="%d" v3="%d"/>' % t for t in tri]
    modell.append('</triangles></mesh></object></resources><build><item objectid="1"/></build></model>')
    typen = ('<?xml version="1.0" encoding="UTF-8"?>\n<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
             '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
             '<Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/></Types>')
    rels = ('<?xml version="1.0" encoding="UTF-8"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>')
    with zipfile.ZipFile(pfad, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml', typen)
        z.writestr('_rels/.rels', rels)
        z.writestr('3D/3dmodel.model', ''.join(modell))


class AMPHION_OT_print(bpy.types.Operator, ExportHelper):
    bl_idname = 'amphion.export_print'
    bl_label = 'Export for 3D print'
    bl_description = 'Check the model and export it to scale in millimetres for 3D printing (STL, 3MF or OBJ)'

    filename_ext = '.stl'
    filter_glob: StringProperty(default='*.stl;*.3mf;*.obj', options={'HIDDEN'})
    massstab: EnumProperty(name='Scale', items=MASSSTAB, default='100')
    format: EnumProperty(name='Format', default='STL', items=[('STL', 'STL', 'Every printer and slicer'),
                                                                ('3MF', '3MF', 'Modern slicers (Prusa, Bambu, Cura), keeps units'),
                                                                ('OBJ', 'OBJ', 'Mesh for other software')])
    auswahl: BoolProperty(name='Selected objects only', default=False)
    wand: FloatProperty(name='Minimum wall (mm)', default=0.8, min=0.2, max=5, description='Thinner parts may break or not print')

    def check(self, context):
        endung = '.' + self.format.lower()
        if not self.filepath.lower().endswith(endung):
            self.filepath = os.path.splitext(self.filepath)[0] + endung
            return True
        return False

    def invoke(self, context, event):
        stamm = os.path.splitext(os.path.basename(bpy.data.filepath))[0] or 'Model'
        self.filepath = os.path.join(os.path.expanduser('~'), stamm + '_1-' + self.massstab + '.stl')
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        objekte = [o for o in modell_objekte(context.scene) if not self.auswahl or o.select_get()]
        if not objekte:
            self.report({'ERROR'}, 'Nothing to export')
            return {'CANCELLED'}
        ok, nachricht = cloud.nutzen('blender')
        if not ok:
            if not bpy.app.background:
                bpy.ops.amphion.subscribe_dialog('INVOKE_DEFAULT')
            return {'CANCELLED'}
        nenner = int(self.massstab)
        faktor = 1000.0 / nenner   # Meter → Millimeter im Maßstab
        dg = context.evaluated_depsgraph_get()
        offen, duenn = pruefen(objekte, self.wand / faktor, dg)
        pkt, tri = _dreiecke(objekte, faktor, dg)
        pfad = os.path.splitext(self.filepath)[0] + '.' + self.format.lower()
        {'STL': stl, '3MF': dreimf, 'OBJ': obj}[self.format](pfad, pkt, tri)
        warnung = []
        if offen:
            warnung.append('%d open edges (holes), most slicers repair them' % offen)
        if duenn > 0.01:
            warnung.append('%d %% of the surface is thinner than %.1f mm at 1:%d' % (round(duenn * 100), self.wand, nenner))
        text = 'Exported %s (%d triangles)' % (os.path.basename(pfad), len(tri))
        self.report({'WARNING'} if warnung else {'INFO'}, text + ('. Check: ' + '; '.join(warnung) if warnung else '. Mesh looks printable.'))
        if nachricht:
            self.report({'INFO'}, nachricht)
        zeigen(pfad)
        return {'FINISHED'}
