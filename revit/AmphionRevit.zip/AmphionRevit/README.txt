Amphion for Revit 1.0.0
AI agent and fast tools for Revit 2023, 2024, 2025 and 2026 (Windows).
https://amphion3d.com/revit/

INSTALL (automatic)
1. Close Revit.
2. Right-click AmphionRevit.zip > Properties > tick "Unblock" > OK (Windows marks downloaded files).
3. Extract the zip, then double-click install.bat.
   It copies Amphion into every installed Revit version for your Windows user.
4. Start Revit. If Revit asks about the add-in, choose "Always Load".
5. Open the "Amphion" tab in the ribbon.

INSTALL (by hand)
Copy the contents of the folder for your Revit year (for example 2025\) into
   %AppData%\Autodesk\Revit\Addins\2025\
so that you have
   %AppData%\Autodesk\Revit\Addins\2025\Amphion.addin
   %AppData%\Autodesk\Revit\Addins\2025\Amphion\AmphionRevit.dll
(Revit 2023 and 2024 use the .NET Framework build, 2025 and 2026 the .NET 8 build; each year folder already has the right one.)

UNINSTALL
Delete Amphion.addin and the Amphion folder from %AppData%\Autodesk\Revit\Addins\<year>\.
Settings are in %AppData%\Amphion\revit.json.

PRICING
AI agent: 5 free AI edits, then 9 EUR per month (or 90 EUR per year) with 300 AI edits per month.
Fast tools (batch sheets, renumber, tag rooms, align tags, dimension walls, rename views,
copy view templates, select similar, purge report, sheets to PDF): free for 30 days, then included in the same subscription.

UNDO
Every AI step is one entry in Revit's Undo list called "Amphion AI: ...". "Undo AI edit" takes back the whole last AI request.
Every fast tool is one Undo entry called "Amphion: ...".

Support: hello@amphion3d.com
