@echo off
rem Amphion for Revit: copies the add-in into every installed Revit version (2023 to 2026) for the current user.
setlocal
set "HIER=%~dp0"
set "ZIEL=%APPDATA%\Autodesk\Revit\Addins"
set /a N=0
powershell -NoProfile -Command "Get-ChildItem -LiteralPath '%HIER%' -Recurse | Unblock-File" >nul 2>&1
for %%Y in (2023 2024 2025 2026) do (
  if exist "%HIER%%%Y\Amphion.addin" (
    if exist "%ProgramFiles%\Autodesk\Revit %%Y" (
      if not exist "%ZIEL%\%%Y\Amphion" mkdir "%ZIEL%\%%Y\Amphion"
      copy /Y "%HIER%%%Y\Amphion.addin" "%ZIEL%\%%Y\" >nul
      copy /Y "%HIER%%%Y\Amphion\*.*" "%ZIEL%\%%Y\Amphion\" >nul
      echo Installed for Revit %%Y
      set /a N+=1
    )
  )
)
if %N%==0 (
  echo No Revit 2023, 2024, 2025 or 2026 found in "%ProgramFiles%\Autodesk".
  echo Copy the folder of your Revit year by hand, see README.txt.
) else (
  echo Done. Start Revit and open the Amphion tab. Choose "Always Load" if Revit asks.
)
pause
